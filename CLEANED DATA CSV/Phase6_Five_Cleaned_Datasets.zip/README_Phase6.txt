PHASE 6 — FIVE DATASET EXPORTS

Created from the five uploaded original CSV files, using the transformations
shown in the uploaded Phase 6 notebook.

1. cleaned_customers.csv
   - Removed duplicate customer_id records (duplicates found: 0).
   - Standardized membership_tier, gender, and state.
   - Replaced missing referral_source, preferred_channel, city, email, and
     phone values with 'Unknown'.
   - Converted date_of_birth and signup_date to datetime; invalid dates become blank/NaT.

2. cleaned_support_tickets.csv
   - Removed duplicate ticket_id records (duplicates found: 0).
   - Standardized issue_category, channel, ticket_status, and resolution_speed
     where those columns exist.
   - Converted ticket_date to datetime; invalid dates become blank/NaT.
   - Filled missing ticket_subject with 'No Subject' only if that column exists.

3. products_with_scaled_unit_price.csv
   - Added scaled_unit_price using MinMaxScaler on unit_price.

4. orders_as_loaded_unchanged.csv
5. order_items_as_loaded_unchanged.csv
   - These were loaded in the Phase 6 notebook, but no cleaning operations for
     them are shown there. They are therefore included unchanged, not described
     as cleaned.

Missing values not addressed by the notebook's specified operations are retained.
